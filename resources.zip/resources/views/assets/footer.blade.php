<footer class="bg-light flex-d border-top border-bottom pt-4 my-md-5">
  <div class="row">
    <div class="col-6 col-sd">
    </div>
    <div class="col-6 col-md">
      <h5>Navigation</h5>
      <ul class="list-unstyled text-small">
        <li><a class="text-muted" href="#">Home</a></li>
        <li><a class="text-muted" href="#">Products</a></li>
        <li><a class="text-muted" href="#">About Us</a></li>
        <li><a class="text-muted" href="#">Admin Page</a></li>
      </ul>
    </div>
    <div class="col-6 col-md">
      <h5>News / Info</h5>
      <ul class="list-unstyled text-small">
        <li><a class="text-muted" href="#">Partnerships</a></li>
        <li><a class="text-muted" href="#">Sustainability</a></li>
        <li><a class="text-muted" href="#">Newsletter</a></li>
        <li><a class="text-muted" href="#">Careers</a></li>
      </ul>
    </div>
  </div>
</footer>

<!-- <footer class="container bg-light">
  <p class="float-right"><a href="#">Home</a></p>
  <p>© 2022 - Aston Sports Ltd. · <a href="#">Contact</a> · <a href="#">Support</a></p>
</footer>
</main> -->
