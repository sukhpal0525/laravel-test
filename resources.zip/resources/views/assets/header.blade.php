  <div class="d-flex flex-column flex-md-row align-items-center px-md-4 bg-white border-bottom">
    <h5 class="my-0 mr-md-auto font-weight-normal"><b>ASTON SPORT</b></h5>
    <nav class="my-2 my-md-0 mr-md-3">
      <a class="p-2 text-dark" href="#">|</a>
      <a class="p-2 text-dark" href="#">Login</a>
      <a class="p-2 text-dark" href="#">|</a>
      <a class="p-2 text-dark" href="#">Register</a>
    </nav>
    <a class=" btn btn-outline-dark" href="#">Admin Page</a>
  </div>
